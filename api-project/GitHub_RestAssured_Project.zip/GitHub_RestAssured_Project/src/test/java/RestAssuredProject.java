import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;


public class RestAssuredProject {
    RequestSpecification requestspec;
    ResponseSpecification responseSpec;
    String sshKey;
    int id;
    //final static String Root_URI = "https://api.github.com";

    @BeforeClass
    public void beforeClass(){
        requestspec = new RequestSpecBuilder().setContentType(ContentType.JSON).addHeader("Authorization","token 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").setBaseUri("https://api.github.com").build();
    }

   @Test(priority = 1)
    public void postRequest(){
        String reqbody = """
                {
                "title": "TestAPIKey",
                "key": "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIEGjZwqHjMrfaC9L2omohmMxnmex4pZgsn6/txWa4DzV gmx\\\\002om0744@IN002OM0"
                }
            """;
        Response response = given().spec(requestspec).body(reqbody).when().post("/user/keys");
        id = response.path("id");
        responseSpec = new ResponseSpecBuilder().expectStatusCode(201).build();

    }
    @Test(priority = 2)
    public void getRequest(){
        Response response = given().spec(requestspec).when().get();
        System.out.println(response.asPrettyString());
        responseSpec = new ResponseSpecBuilder().expectStatusCode(200).build();
    }
    @Test(priority = 3)
    public void deleteRequest(){
        Response response = given().spec(requestspec).when().pathParam("keyID",id).delete("/{keyID}");
        System.out.println(response.asPrettyString());
        responseSpec = new ResponseSpecBuilder().expectStatusCode(204).build();
    }
}
